package com.shopeedivulgaai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Pink = Color(0xFFE91E63)
private val DeepPink = Color(0xFFC2185B)
private val Ink = Color(0xFF191319)
private val Soft = Color(0xFFFFF2F6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShopeeApp() }
    }
}

@Composable
fun ShopeeApp() {
    var page by remember { mutableStateOf("Início") }
    MaterialTheme(colorScheme = lightColorScheme(primary = Pink, secondary = DeepPink, background = Color.White)) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val items = listOf("Início", "Produtos", "Vídeos", "Resultados")
                    val icons = listOf(Icons.Default.Home, Icons.Default.ShoppingBag, Icons.Default.VideoLibrary, Icons.Default.BarChart)
                    items.forEachIndexed { i, label ->
                        NavigationBarItem(selected = page == label, onClick = { page = label }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 10.sp) })
                    }
                }
            }
        ) { padding ->
            when (page) {
                "Início" -> HomeScreen(Modifier.padding(padding), onNavigate = { page = it })
                "Produtos" -> InfoScreen(Modifier.padding(padding), "Produtos", "Aqui ficará sua busca e seleção de produtos da Shopee.", Icons.Default.ShoppingBag)
                "Vídeos" -> InfoScreen(Modifier.padding(padding), "Estúdio de vídeos", "Aqui você poderá criar roteiros, vídeos, narrações e legendas com IA.", Icons.Default.VideoLibrary)
                else -> InfoScreen(Modifier.padding(padding), "Resultados", "Aqui aparecerão publicações, visualizações, cliques e comissões disponíveis.", Icons.Default.BarChart)
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier, onNavigate: (String) -> Unit) {
    LazyColumn(modifier.fillMaxSize().background(Color(0xFFFFFAFC)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("Shopee Divulga AI", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text("Sua central de divulgação", color = Color.Gray, fontSize = 14.sp)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Ink), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("PRONTA PARA DIVULGAR?", color = Color(0xFFFFB6CF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Transforme produtos em vídeos", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("Encontre ideias, prepare seu conteúdo e organize suas publicações.", color = Color(0xFFE9E1E5), fontSize = 13.sp)
                    Button(onClick = { onNavigate("Produtos") }, colors = ButtonDefaults.buttonColors(containerColor = Pink), modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text("COMEÇAR")
                    }
                }
            }
        }
        item { Text("Seu painel", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Vídeos", "0", Modifier.weight(1f))
                MetricCard("Publicados", "0", Modifier.weight(1f))
                MetricCard("Cliques", "0", Modifier.weight(1f))
            }
        }
        item {
            ActionRow("Encontrar produtos", "Explore itens para divulgar", Icons.Default.Search) { onNavigate("Produtos") }
        }
        item {
            ActionRow("Criar vídeo com IA", "Roteiro, legenda e narração", Icons.Default.MovieCreation) { onNavigate("Vídeos") }
        }
        item {
            ActionRow("Ver resultados", "Acompanhe seu desempenho", Icons.Default.Insights) { onNavigate("Resultados") }
        }
        item {
            Text("Atenção: esta é a primeira versão visual. A busca real de produtos, geração de vídeos e publicação dependem de integrações e permissões oficiais. Nunca informe sua senha da Shopee dentro do app.", fontSize = 11.sp, color = Color.Gray)
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Soft), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(value, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = DeepPink)
            Text(title, fontSize = 11.sp, color = Ink)
        }
    }
}

@Composable
fun ActionRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(Soft, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Pink) }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = Ink)
                Text(subtitle, fontSize = 12.sp, color = Color.Gray)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Pink)
        }
    }
}

@Composable
fun InfoScreen(modifier: Modifier, title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(modifier.fillMaxSize().background(Color(0xFFFFFAFC)).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Icon(icon, null, tint = Pink, modifier = Modifier.size(42.dp))
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(description, color = Color.DarkGray)
        Card(colors = CardDefaults.cardColors(containerColor = Soft), shape = RoundedCornerShape(16.dp)) {
            Text("Em desenvolvimento", Modifier.padding(16.dp), color = DeepPink, fontWeight = FontWeight.Bold)
        }
    }
}
